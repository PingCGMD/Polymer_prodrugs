#!/bin/bash

module purge
module load gcc/8.2.0
module load gromacs/2019.2

gmx grompp -f dynamic.mdp -c equilibration.gro -p system.top -o dynamic.tpr -n system.ndx

